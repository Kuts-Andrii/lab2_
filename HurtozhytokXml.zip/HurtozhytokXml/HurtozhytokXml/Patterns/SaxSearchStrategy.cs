using System.Xml;

namespace HurtozhytokXml;

public class SaxSearchStrategy : ISearchStrategy
{
    public string LastQuery => "XmlReader: послідовне читання файлу";

    public List<Student> Search(string path, SearchParams parameters)
    {
        var result = new List<Student>();
        Student? current = null;

        using var reader = XmlReader.Create(path);
        while (reader.Read())
        {
            if (IsElement(reader, "Student"))
            {
                bool isEmpty = reader.IsEmptyElement;
                current = ReadStudent(reader);

                if (isEmpty)
                {
                    AddIfFits(result, current, parameters);
                    current = null;
                }
            }
            else if (IsElement(reader, "Accommodation") && current != null)
            {
                current.Living.Add(ReadAccommodation(reader));
            }
            else if (reader.NodeType == XmlNodeType.EndElement && reader.Name == "Student" && current != null)
            {
                AddIfFits(result, current, parameters);
                current = null;
            }
        }

        return result;
    }

    private static bool IsElement(XmlReader reader, string name)
    {
        return reader.NodeType == XmlNodeType.Element && reader.Name == name;
    }

    private static Student ReadStudent(XmlReader reader)
    {
        var student = new Student();
        while (reader.MoveToNextAttribute())
            student.Attributes[reader.Name] = reader.Value;
        return student;
    }

    private static Accommodation ReadAccommodation(XmlReader reader)
    {
        return new Accommodation
        {
            Floor = reader.GetAttribute("Floor") ?? "",
            Room = reader.GetAttribute("Room") ?? "",
            From = reader.GetAttribute("From") ?? "",
            To = reader.GetAttribute("To") ?? ""
        };
    }

    private static void AddIfFits(List<Student> result, Student student, SearchParams parameters)
    {
        if (Fits(student, parameters))
            result.Add(student);
    }

    private static bool Fits(Student student, SearchParams parameters)
    {
        foreach (var filter in parameters.Attributes)
        {
            if (!student.Attributes.TryGetValue(filter.Key, out var value) || value != filter.Value)
                return false;
        }

        if (!string.IsNullOrEmpty(parameters.Floor) &&
            !student.Living.Any(l => l.Floor == parameters.Floor))
            return false;

        string keyword = parameters.KeywordLower;
        if (keyword != "" &&
            !student.Attributes.Values.Any(v => v.ToLowerInvariant().Contains(keyword)))
            return false;

        return true;
    }
}
