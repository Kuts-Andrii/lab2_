namespace HurtozhytokXml;

public interface ISearchStrategy
{
    string LastQuery { get; }

    List<Student> Search(string path, SearchParams parameters);
}
