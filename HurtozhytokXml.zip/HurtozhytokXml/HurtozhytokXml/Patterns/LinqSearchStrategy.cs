using System.Xml.Linq;

namespace HurtozhytokXml;

public class LinqSearchStrategy : ISearchStrategy
{
    public string LastQuery { get; private set; } = "";

    public List<Student> Search(string path, SearchParams parameters)
    {
        var document = XDocument.Load(path);
        IEnumerable<XElement> query = document.Root?.Elements("Student") ?? Enumerable.Empty<XElement>();
        string queryText = "Elements(\"Student\")";

        foreach (var filter in parameters.Attributes)
        {
            string name = filter.Key;
            string value = filter.Value;
            query = query.Where(s => (string?)s.Attribute(name) == value);
            queryText += $".Where({name} == \"{value}\")";
        }

        if (!string.IsNullOrEmpty(parameters.Floor))
        {
            string floor = parameters.Floor;
            query = query.Where(s => s.Elements("Accommodation")
                                      .Any(a => (string?)a.Attribute("Floor") == floor));
            queryText += $".Where(Floor == \"{floor}\")";
        }

        string keyword = parameters.KeywordLower;
        if (keyword != "")
        {
            query = query.Where(s => s.Attributes().Any(a => a.Value.ToLowerInvariant().Contains(keyword)));
            queryText += $".Where(contains \"{keyword}\")";
        }

        LastQuery = queryText;

        return query.Select(s => Student.FromXElement(s)).ToList();
    }
}
