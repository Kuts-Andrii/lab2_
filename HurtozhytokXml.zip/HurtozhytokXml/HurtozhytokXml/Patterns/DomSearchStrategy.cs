using System.Xml;

namespace HurtozhytokXml;

public class DomSearchStrategy : ISearchStrategy
{
    private const string UpperLetters = "АБВГҐДЕЄЖЗИІЇЙКЛМНОПРСТУФХЦЧШЩЬЮЯABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static readonly string LowerLetters = UpperLetters.ToLowerInvariant();

    public string LastQuery { get; private set; } = "";

    public List<Student> Search(string path, SearchParams parameters)
    {
        var document = new XmlDocument();
        document.Load(path);

        LastQuery = BuildXPath(parameters);

        var result = new List<Student>();
        XmlNodeList? nodes = document.SelectNodes(LastQuery);
        if (nodes == null)
            return result;

        foreach (XmlNode node in nodes)
            result.Add(ToStudent(node));

        return result;
    }

    public static string BuildXPath(SearchParams parameters)
    {
        var conditions = new List<string>();

        foreach (var filter in parameters.Attributes)
            conditions.Add($"@{filter.Key}={Literal(filter.Value)}");

        if (!string.IsNullOrEmpty(parameters.Floor))
            conditions.Add($"Accommodation[@Floor={Literal(parameters.Floor)}]");

        string keyword = parameters.KeywordLower.Replace("\"", "");
        if (keyword != "")
            conditions.Add($"@*[contains(translate(., '{UpperLetters}', '{LowerLetters}'), {Literal(keyword)})]");

        string xpath = "/Dormitory/Student";
        if (conditions.Count > 0)
            xpath += "[" + string.Join(" and ", conditions) + "]";

        return xpath;
    }

    private static string Literal(string value)
    {
        return value.Contains('\'') ? $"\"{value}\"" : $"'{value}'";
    }

    private static Student ToStudent(XmlNode node)
    {
        var student = new Student();

        if (node.Attributes != null)
        {
            foreach (XmlAttribute attribute in node.Attributes)
                student.Attributes[attribute.Name] = attribute.Value;
        }

        foreach (XmlNode child in node.ChildNodes)
        {
            if (child.Name == "Accommodation")
                student.Living.Add(ToAccommodation(child));
        }

        return student;
    }

    private static Accommodation ToAccommodation(XmlNode node)
    {
        return new Accommodation
        {
            Floor = node.Attributes?["Floor"]?.Value ?? "",
            Room = node.Attributes?["Room"]?.Value ?? "",
            From = node.Attributes?["From"]?.Value ?? "",
            To = node.Attributes?["To"]?.Value ?? ""
        };
    }
}
