namespace HurtozhytokXml;

public enum ProtocolLevel
{
    Filter,
    Transform,
    Save
}

public sealed class ProtocolLogger
{
    private static ProtocolLogger? instance;
    private static readonly object locker = new();

    private readonly string logPath;

    private ProtocolLogger()
    {
        Directory.CreateDirectory(AppPaths.OutputFolder);
        logPath = Path.Combine(AppPaths.OutputFolder, "log.txt");
    }

    public static ProtocolLogger GetInstance()
    {
        lock (locker)
        {
            instance ??= new ProtocolLogger();
            return instance;
        }
    }

    public void Log(ProtocolLevel level, string message)
    {
        string line = $"{DateTime.Now:dd.MM.yyyy HH:mm:ss} {LevelName(level)}. {message}";
        lock (locker)
        {
            File.AppendAllText(logPath, line + Environment.NewLine);
        }
    }

    private static string LevelName(ProtocolLevel level) => level switch
    {
        ProtocolLevel.Filter => "Фільтрація",
        ProtocolLevel.Transform => "Трансформація",
        _ => "Збереження"
    };
}

public static class AppPaths
{
    public static string OutputFolder =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "HurtozhytokXml");

    public static string DriveCacheFolder => Path.Combine(OutputFolder, "FromDrive");

    public static string TokenFolder => Path.Combine(OutputFolder, "token");
}
