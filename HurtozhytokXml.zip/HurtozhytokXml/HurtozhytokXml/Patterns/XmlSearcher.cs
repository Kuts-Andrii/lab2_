namespace HurtozhytokXml;

public class XmlSearcher
{
    private ISearchStrategy strategy;

    public XmlSearcher(ISearchStrategy strategy)
    {
        this.strategy = strategy;
    }

    public string LastQuery => strategy.LastQuery;

    public void SetStrategy(ISearchStrategy strategy)
    {
        this.strategy = strategy;
    }

    public List<Student> Search(string path, SearchParams parameters)
    {
        return strategy.Search(path, parameters);
    }
}
