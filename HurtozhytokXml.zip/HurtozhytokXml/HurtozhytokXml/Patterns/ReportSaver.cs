using System.Xml;
using System.Xml.Linq;
using System.Xml.Xsl;

namespace HurtozhytokXml;

public interface IReport
{
    void Write(XDocument data, Stream stream);
}

public class XmlReport : IReport
{
    public void Write(XDocument data, Stream stream)
    {
        data.Save(stream);
    }
}

public class HtmlReport : IReport
{
    private readonly XslCompiledTransform transform;

    public HtmlReport(XslCompiledTransform transform)
    {
        this.transform = transform;
    }

    public void Write(XDocument data, Stream stream)
    {
        using var reader = data.CreateReader();
        using var writer = XmlWriter.Create(stream, transform.OutputSettings);
        transform.Transform(reader, writer);
    }
}

public abstract class ReportSaver
{
    public abstract string Extension { get; }

    public abstract string MimeType { get; }

    protected abstract IReport CreateReport();

    public string Save(XDocument data, string folder, string fileName)
    {
        Directory.CreateDirectory(folder);
        string path = Path.Combine(folder, fileName + Extension);

        using var stream = new FileStream(path, FileMode.Create);
        CreateReport().Write(data, stream);

        return path;
    }

    public async Task<string> SaveToDriveAsync(XDocument data, GoogleDriveStorage drive, string fileName)
    {
        string name = fileName + Extension;

        using var stream = new MemoryStream();
        CreateReport().Write(data, stream);
        stream.Position = 0;

        await drive.UploadAsync(stream, name, MimeType);
        return name;
    }
}

public class XmlReportSaver : ReportSaver
{
    public override string Extension => ".xml";

    public override string MimeType => "text/xml";

    protected override IReport CreateReport() => new XmlReport();
}

public class HtmlReportSaver : ReportSaver
{
    private readonly XslCompiledTransform transform;

    public HtmlReportSaver(XslCompiledTransform transform)
    {
        this.transform = transform;
    }

    public override string Extension => ".html";

    public override string MimeType => "text/html";

    protected override IReport CreateReport() => new HtmlReport(transform);
}
