using Foundation;

namespace HurtozhytokXml
{
    [Register("SceneDelegate")]
    public class SceneDelegate : MauiUISceneDelegate
    {
    }
}
