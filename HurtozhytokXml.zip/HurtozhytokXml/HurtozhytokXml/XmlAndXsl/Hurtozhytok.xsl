<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
  <xsl:output method="html" encoding="utf-8" indent="yes"/>

  <xsl:template match="/Dormitory">
    <html>
      <head>
        <title><xsl:value-of select="@Name"/></title>
      </head>
      <body>
        <h2><xsl:value-of select="@Name"/></h2>
        <p>Кількість студентів: <xsl:value-of select="count(Student)"/></p>
        <table border="1" cellpadding="4" cellspacing="0">
          <tr>
            <th>№</th>
            <th>ПІБ</th>
            <th>Факультет</th>
            <th>Кафедра</th>
            <th>Курс</th>
            <th>Інше</th>
            <th>Проживання</th>
          </tr>
          <xsl:apply-templates select="Student">
            <xsl:sort select="@Name"/>
          </xsl:apply-templates>
        </table>
      </body>
    </html>
  </xsl:template>

  <xsl:template match="Student">
    <tr>
      <td><xsl:value-of select="position()"/></td>
      <td><xsl:value-of select="@Name"/></td>
      <td><xsl:value-of select="@Faculty"/></td>
      <td><xsl:value-of select="@Department"/></td>
      <td><xsl:value-of select="@Course"/></td>
      <td>
        <xsl:for-each select="@*[not(name()='Name' or name()='Faculty' or name()='Department' or name()='Course')]">
          <xsl:choose>
            <xsl:when test="name()='Group'">Група</xsl:when>
            <xsl:when test="name()='Phone'">Телефон</xsl:when>
            <xsl:when test="name()='Benefit'">Пільга</xsl:when>
            <xsl:otherwise><xsl:value-of select="name()"/></xsl:otherwise>
          </xsl:choose>
          <xsl:text>: </xsl:text>
          <xsl:value-of select="."/>
          <br/>
        </xsl:for-each>
      </td>
      <td>
        <xsl:for-each select="Accommodation">
          <xsl:text>пов. </xsl:text><xsl:value-of select="@Floor"/>
          <xsl:text>, кім. </xsl:text><xsl:value-of select="@Room"/>
          <xsl:text> (</xsl:text><xsl:value-of select="@From"/>
          <xsl:text> - </xsl:text><xsl:value-of select="@To"/>
          <xsl:text>)</xsl:text>
          <br/>
        </xsl:for-each>
      </td>
    </tr>
  </xsl:template>
</xsl:stylesheet>
