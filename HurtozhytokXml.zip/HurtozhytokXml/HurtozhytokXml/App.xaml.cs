﻿using Microsoft.Extensions.DependencyInjection;

namespace HurtozhytokXml
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }

        protected override Window CreateWindow(IActivationState? activationState)
        {
            return new Window(new AppShell());
        }
    }
}