using Google.Apis.Auth.OAuth2;
using Google.Apis.Auth.OAuth2.Responses;
using Google.Apis.Download;
using Google.Apis.Drive.v3;
using Google.Apis.Services;
using Google.Apis.Upload;
using Google.Apis.Util.Store;
using DriveFile = Google.Apis.Drive.v3.Data.File;

namespace HurtozhytokXml;

public class GoogleDriveStorage
{
    private const string FolderName = "HurtozhytokXml";
    private const string FolderMimeType = "application/vnd.google-apps.folder";

    private DriveService? service;
    private string folderId = "";

    public bool IsConnected => service != null;

    private DriveService Service =>
        service ?? throw new InvalidOperationException("Google Drive не підключено.");

    public async Task ConnectAsync(Stream credentials, string tokenFolder)
    {
        var secrets = GoogleClientSecrets.FromStream(credentials).Secrets;

        try
        {
            await AuthorizeAsync(secrets, tokenFolder);
        }
        catch (TokenResponseException)
        {
            if (Directory.Exists(tokenFolder))
                Directory.Delete(tokenFolder, true);

            await AuthorizeAsync(secrets, tokenFolder);
        }
    }

    private async Task AuthorizeAsync(ClientSecrets secrets, string tokenFolder)
    {
        var credential = await GoogleWebAuthorizationBroker.AuthorizeAsync(
            secrets,
            new[] { DriveService.Scope.Drive },
            "user",
            CancellationToken.None,
            new FileDataStore(tokenFolder, true));

        service = new DriveService(new BaseClientService.Initializer
        {
            HttpClientInitializer = credential,
            ApplicationName = "HurtozhytokXml"
        });

        try
        {
            folderId = await GetOrCreateFolderAsync();
        }
        catch
        {
            service = null;
            throw;
        }
    }

    public async Task<List<string>> ListFileNamesAsync(string extension)
    {
        var request = Service.Files.List();
        request.Q = $"'{folderId}' in parents and name contains '{Escape(extension)}' and trashed=false";
        request.Fields = "files(id, name)";
        request.OrderBy = "name";

        var result = await request.ExecuteAsync();
        return result.Files
            .Select(f => f.Name)
            .Where(n => n.EndsWith(extension, StringComparison.OrdinalIgnoreCase))
            .ToList();
    }

    public async Task<bool> ExistsAsync(string name)
    {
        return await FindFileIdAsync(name) != null;
    }

    public async Task DownloadAsync(string name, string localPath)
    {
        string fileId = await FindFileIdAsync(name)
            ?? throw new FileNotFoundException($"На Google Drive немає файлу {name}");

        using var stream = new FileStream(localPath, FileMode.Create);
        var progress = await Service.Files.Get(fileId).DownloadAsync(stream);

        if (progress.Status == DownloadStatus.Failed)
            throw progress.Exception;
    }

    public async Task UploadFileAsync(string localPath, string mimeType)
    {
        using var stream = new FileStream(localPath, FileMode.Open, FileAccess.Read);
        await UploadAsync(stream, Path.GetFileName(localPath), mimeType);
    }

    public async Task UploadAsync(Stream content, string name, string mimeType)
    {
        string? existingId = await FindFileIdAsync(name);

        IUploadProgress progress;
        if (existingId == null)
        {
            var file = new DriveFile { Name = name, Parents = new List<string> { folderId } };
            progress = await Service.Files.Create(file, content, mimeType).UploadAsync();
        }
        else
        {
            progress = await Service.Files.Update(new DriveFile(), existingId, content, mimeType).UploadAsync();
        }

        if (progress.Status == UploadStatus.Failed)
            throw progress.Exception;
    }

    private async Task<string> GetOrCreateFolderAsync()
    {
        var request = Service.Files.List();
        request.Q = $"mimeType='{FolderMimeType}' and name='{FolderName}' and trashed=false";
        request.Fields = "files(id)";

        var result = await request.ExecuteAsync();
        if (result.Files.Count > 0)
            return result.Files[0].Id;

        var folder = new DriveFile { Name = FolderName, MimeType = FolderMimeType };
        var create = Service.Files.Create(folder);
        create.Fields = "id";

        var created = await create.ExecuteAsync();
        return created.Id;
    }

    private async Task<string?> FindFileIdAsync(string name)
    {
        var request = Service.Files.List();
        request.Q = $"'{folderId}' in parents and name='{Escape(name)}' and trashed=false";
        request.Fields = "files(id)";

        var result = await request.ExecuteAsync();
        return result.Files.FirstOrDefault()?.Id;
    }

    private static string Escape(string value)
    {
        return value.Replace("\\", "\\\\").Replace("'", "\\'");
    }
}
