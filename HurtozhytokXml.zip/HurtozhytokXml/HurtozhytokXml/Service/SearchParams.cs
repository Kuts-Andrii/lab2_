namespace HurtozhytokXml;

public class SearchParams
{
    public Dictionary<string, string> Attributes { get; } = new();
    public string? Floor { get; set; }
    public string? Keyword { get; set; }

    public string KeywordLower => (Keyword ?? "").Trim().ToLowerInvariant();

    public override string ToString()
    {
        var parts = Attributes.Select(a => $"«{Labels.Get(a.Key)}» – {a.Value}").ToList();

        if (!string.IsNullOrEmpty(Floor))
            parts.Add($"«Поверх» – {Floor}");

        if (KeywordLower != "")
            parts.Add($"«Ключове слово» – {Keyword!.Trim()}");

        return parts.Count == 0 ? "без параметрів" : string.Join(", ", parts);
    }
}

public static class Labels
{
    private static readonly Dictionary<string, string> names = new()
    {
        ["Name"] = "ПІБ",
        ["Faculty"] = "Факультет",
        ["Department"] = "Кафедра",
        ["Course"] = "Курс",
        ["Group"] = "Група",
        ["Phone"] = "Телефон",
        ["Benefit"] = "Пільга",
        ["Floor"] = "Поверх"
    };

    public static string Get(string attribute) =>
        names.TryGetValue(attribute, out var label) ? label : attribute;
}
