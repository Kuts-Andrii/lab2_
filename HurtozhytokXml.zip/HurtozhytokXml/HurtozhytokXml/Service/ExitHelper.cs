namespace HurtozhytokXml;

public static class ExitHelper
{
    private static bool isAsking;

    public static bool Confirmed { get; private set; }

    public static async Task AskAsync(Page page)
    {
        if (isAsking)
            return;

        isAsking = true;
        try
        {
            bool exit = await page.DisplayAlertAsync("Вихід",
                "Чи дійсно ви хочете завершити роботу з програмою?", "Так", "Ні");

            if (exit)
            {
                Confirmed = true;
                Application.Current?.Quit();
            }
        }
        finally
        {
            isAsking = false;
        }
    }
}
