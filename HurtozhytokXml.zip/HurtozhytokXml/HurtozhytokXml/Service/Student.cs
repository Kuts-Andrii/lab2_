using System.Xml.Linq;

namespace HurtozhytokXml;

public class Accommodation
{
    public string Floor { get; set; } = "";
    public string Room { get; set; } = "";
    public string From { get; set; } = "";
    public string To { get; set; } = "";
}

public class Student
{
    public Dictionary<string, string> Attributes { get; } = new();
    public List<Accommodation> Living { get; } = new();

    public string Name => Attributes.TryGetValue("Name", out var name) ? name : "";

    public static Student FromXElement(XElement element)
    {
        var student = new Student();

        foreach (var attribute in element.Attributes())
            student.Attributes[attribute.Name.LocalName] = attribute.Value;

        foreach (var living in element.Elements("Accommodation"))
        {
            student.Living.Add(new Accommodation
            {
                Floor = (string?)living.Attribute("Floor") ?? "",
                Room = (string?)living.Attribute("Room") ?? "",
                From = (string?)living.Attribute("From") ?? "",
                To = (string?)living.Attribute("To") ?? ""
            });
        }

        return student;
    }

    public XElement ToXElement()
    {
        var element = new XElement("Student",
            Attributes.Select(a => new XAttribute(a.Key, a.Value)));

        foreach (var living in Living)
        {
            element.Add(new XElement("Accommodation",
                new XAttribute("Floor", living.Floor),
                new XAttribute("Room", living.Room),
                new XAttribute("From", living.From),
                new XAttribute("To", living.To)));
        }

        return element;
    }
}
