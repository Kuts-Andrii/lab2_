using System.Text;
using System.Xml.Linq;
using System.Xml.Xsl;
using Microsoft.Maui.Storage;

namespace HurtozhytokXml;

public class FileValues
{
    public List<string> Faculties { get; init; } = new();
    public List<string> Departments { get; init; } = new();
    public List<string> Courses { get; init; } = new();
    public List<string> Floors { get; init; } = new();
}

public class HurtozhytokService
{
    private const string XslFileName = "Hurtozhytok.xsl";

    private readonly Dictionary<string, ISearchStrategy> strategies = new()
    {
        ["SAX"] = new SaxSearchStrategy(),
        ["DOM"] = new DomSearchStrategy(),
        ["LINQ"] = new LinqSearchStrategy()
    };

    private readonly XmlSearcher searcher;
    private readonly GoogleDriveStorage drive = new();
    private XslCompiledTransform? transform;
    private string hurtozhytokName = "Гуртожиток";
    private bool searched;

    public HurtozhytokService()
    {
        searcher = new XmlSearcher(strategies["SAX"]);
    }

    public string? FilePath { get; private set; }
    public List<Student> Found { get; private set; } = new();

    public FileValues Open(string path)
    {
        var document = XDocument.Load(path);
        if (document.Root?.Name.LocalName != "Dormitory")
            throw new InvalidDataException("кореневий елемент має бути <Dormitory>");

        FilePath = path;
        transform = null;
        hurtozhytokName = (string?)document.Root.Attribute("Name") ?? "Гуртожиток";
        ClearResult();

        var students = document.Root.Elements("Student").ToList();
        return new FileValues
        {
            Faculties = DistinctValues(students, "Faculty"),
            Departments = DistinctValues(students, "Department"),
            Courses = DistinctValues(students, "Course"),
            Floors = DistinctValues(students.Elements("Accommodation"), "Floor")
        };
    }

    public string Search(string method, SearchParams parameters)
    {
        string path = RequireFile();

        searcher.SetStrategy(strategies[method]);
        Found = searcher.Search(path, parameters);
        searched = true;

        ProtocolLogger.GetInstance().Log(ProtocolLevel.Filter,
            $"Параметри: {parameters}. Спосіб: {method}. Знайдено: {Found.Count}");

        return FormatResult(method, searcher.LastQuery, Found);
    }

    public void ClearResult()
    {
        Found = new();
        searched = false;
    }

    public string SaveHtml()
    {
        string path = new HtmlReportSaver(LoadTransform()).Save(ResultDocument(), AppPaths.OutputFolder, NewFileName());

        ProtocolLogger.GetInstance().Log(ProtocolLevel.Transform,
            "Збережено у файл " + Path.GetFileName(path));

        return path;
    }

    public async Task<List<string>> GetDriveXmlFilesAsync()
    {
        await ConnectDriveAsync();
        return await drive.ListFileNamesAsync(".xml");
    }

    public async Task<FileValues> OpenFromDriveAsync(string name)
    {
        await ConnectDriveAsync();
        Directory.CreateDirectory(AppPaths.DriveCacheFolder);

        string xmlPath = Path.Combine(AppPaths.DriveCacheFolder, name);
        await drive.DownloadAsync(name, xmlPath);

        if (await drive.ExistsAsync(XslFileName))
            await drive.DownloadAsync(XslFileName, Path.Combine(AppPaths.DriveCacheFolder, XslFileName));

        return Open(xmlPath);
    }

    public async Task UploadSourcesToDriveAsync()
    {
        string xmlPath = RequireFile();
        string xslPath = XslPath();
        await ConnectDriveAsync();

        await drive.UploadFileAsync(xmlPath, "text/xml");
        string uploaded = Path.GetFileName(xmlPath);

        if (File.Exists(xslPath))
        {
            await drive.UploadFileAsync(xslPath, "text/xml");
            uploaded += ", " + XslFileName;
        }

        ProtocolLogger.GetInstance().Log(ProtocolLevel.Save,
            "На Google Drive збережено файли " + uploaded);
    }

    public async Task<string> SaveXmlToDriveAsync()
    {
        var document = ResultDocument();
        await ConnectDriveAsync();

        string name = await new XmlReportSaver().SaveToDriveAsync(document, drive, NewFileName());

        ProtocolLogger.GetInstance().Log(ProtocolLevel.Save,
            "Збережено відфільтрований фрагмент на Google Drive у файл " + name);

        return name;
    }

    public async Task<string> SaveHtmlToDriveAsync()
    {
        var document = ResultDocument();
        var xslt = LoadTransform();
        await ConnectDriveAsync();

        string name = await new HtmlReportSaver(xslt).SaveToDriveAsync(document, drive, NewFileName());

        ProtocolLogger.GetInstance().Log(ProtocolLevel.Transform,
            "Збережено на Google Drive у файл " + name);

        return name;
    }

    private async Task ConnectDriveAsync()
    {
        if (drive.IsConnected)
            return;

        const string fileName = "credentials.json";
        if (!await FileSystem.AppPackageFileExistsAsync(fileName))
            throw new FileNotFoundException($"Не знайдено {fileName} у Resources/Raw проєкту.");

        using var credentials = await FileSystem.OpenAppPackageFileAsync(fileName);
        await drive.ConnectAsync(credentials, AppPaths.TokenFolder);
    }

    private string XslPath()
    {
        string folder = Path.GetDirectoryName(RequireFile()) ?? "";
        return Path.Combine(folder, XslFileName);
    }

    private string RequireFile()
    {
        return FilePath ?? throw new InvalidOperationException("Спочатку відкрийте XML-файл.");
    }

    private XDocument ResultDocument()
    {
        string path = RequireFile();

        if (!searched)
            return XDocument.Load(path);

        var root = new XElement("Dormitory",
            new XAttribute("Name", hurtozhytokName),
            Found.Select(s => s.ToXElement()));

        return new XDocument(new XDeclaration("1.0", "utf-8", null), root);
    }

    private XslCompiledTransform LoadTransform()
    {
        string xslPath = XslPath();

        if (!File.Exists(xslPath))
            throw new FileNotFoundException($"Поруч з XML-файлом немає {XslFileName}");

        if (transform == null)
        {
            transform = new XslCompiledTransform();
            transform.Load(xslPath);
        }

        return transform;
    }

    private static string NewFileName() => "result_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");

    private static List<string> DistinctValues(IEnumerable<XElement> elements, string attribute)
    {
        return elements
            .Select(e => (string?)e.Attribute(attribute))
            .OfType<string>()
            .Where(v => v != "")
            .Distinct()
            .OrderBy(v => int.TryParse(v, out int number) ? number : int.MaxValue)
            .ThenBy(v => v)
            .ToList();
    }

    private static string FormatResult(string method, string query, List<Student> students)
    {
        var text = new StringBuilder();
        text.AppendLine("Спосіб: " + method);
        text.AppendLine("Запит: " + query);
        text.AppendLine("Знайдено: " + students.Count);
        text.AppendLine();

        if (students.Count == 0)
            text.AppendLine("Нічого не знайдено.");

        for (int i = 0; i < students.Count; i++)
        {
            Student student = students[i];
            text.AppendLine($"{i + 1}. {student.Name}");

            foreach (var attribute in student.Attributes.Where(a => a.Key != "Name"))
                text.AppendLine($"   {Labels.Get(attribute.Key)}: {attribute.Value}");

            foreach (var living in student.Living)
                text.AppendLine($"   Проживання: пов. {living.Floor}, кім. {living.Room} ({living.From} - {living.To})");

            text.AppendLine();
        }

        return text.ToString();
    }
}
