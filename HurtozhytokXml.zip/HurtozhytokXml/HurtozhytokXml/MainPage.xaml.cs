using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Devices;
using Microsoft.Maui.Storage;

namespace HurtozhytokXml;

public partial class MainPage : ContentPage
{
    private readonly HurtozhytokService service = new();

    private static readonly PickOptions XmlPickOptions = new()
    {
        PickerTitle = "Виберіть XML-файл",
        FileTypes = new FilePickerFileType(new Dictionary<DevicePlatform, IEnumerable<string>>
        {
            [DevicePlatform.WinUI] = new[] { ".xml" },
            [DevicePlatform.MacCatalyst] = new[] { "xml" },
            [DevicePlatform.Android] = new[] { "text/xml", "application/xml" },
            [DevicePlatform.iOS] = new[] { "public.xml" }
        })
    };

    public MainPage()
    {
        InitializeComponent();
    }

    private async void OnOpenClicked(object? sender, EventArgs e)
    {
        var file = await FilePicker.Default.PickAsync(XmlPickOptions);
        if (file == null)
            return;

        await RunSafe(() =>
        {
            ShowFile(service.Open(file.FullPath), file.FullPath);
            return Task.CompletedTask;
        });
    }

    private async void OnSearchClicked(object? sender, EventArgs e)
    {
        await RunSafe(() =>
        {
            output.Text = service.Search(SelectedMethod(), ReadParams());
            statusLabel.Text = "Знайдено: " + service.Found.Count;
            return Task.CompletedTask;
        });
    }

    private void OnClearClicked(object? sender, EventArgs e)
    {
        ResetForm();
        service.ClearResult();
    }

    private async void OnHtmlClicked(object? sender, EventArgs e)
    {
        await RunSafe(async () =>
        {
            string path = service.SaveHtml();
            statusLabel.Text = "HTML: " + path;
            await Launcher.Default.OpenAsync(new OpenFileRequest("Результат", new ReadOnlyFile(path)));
        });
    }

    private async void OnDriveOpenClicked(object? sender, EventArgs e)
    {
        await RunSafe(async () =>
        {
            statusLabel.Text = "Підключення до Google Drive...";
            List<string> files = await service.GetDriveXmlFilesAsync();
            statusLabel.Text = "";

            if (files.Count == 0)
            {
                await DisplayAlertAsync("Google Drive", "У папці HurtozhytokXml на Drive немає XML-файлів.", "OK");
                return;
            }

            string choice = await DisplayActionSheetAsync("Файл на Google Drive", "Скасувати", null, files.ToArray());
            if (!files.Contains(choice))
                return;

            ShowFile(await service.OpenFromDriveAsync(choice), "Google Drive: " + choice);
        });
    }

    private async void OnDriveUploadClicked(object? sender, EventArgs e)
    {
        await RunSafe(async () =>
        {
            await service.UploadSourcesToDriveAsync();
            statusLabel.Text = "XML і XSL збережено на Google Drive";
        });
    }

    private async void OnDriveSaveXmlClicked(object? sender, EventArgs e)
    {
        await RunSafe(async () =>
        {
            statusLabel.Text = "Drive: " + await service.SaveXmlToDriveAsync();
        });
    }

    private async void OnDriveSaveHtmlClicked(object? sender, EventArgs e)
    {
        await RunSafe(async () =>
        {
            statusLabel.Text = "Drive: " + await service.SaveHtmlToDriveAsync();
        });
    }

    private async Task RunSafe(Func<Task> action)
    {
        try
        {
            await action();
        }
        catch (Exception ex)
        {
            statusLabel.Text = "";
            await DisplayAlertAsync("Помилка", ex.Message, "OK");
        }
    }

    private void ShowFile(FileValues values, string title)
    {
        facultyPicker.ItemsSource = values.Faculties;
        departmentPicker.ItemsSource = values.Departments;
        coursePicker.ItemsSource = values.Courses;
        floorPicker.ItemsSource = values.Floors;

        ResetForm();
        fileLabel.Text = title;
    }

    private string SelectedMethod()
    {
        if (domRadio.IsChecked) return "DOM";
        if (linqRadio.IsChecked) return "LINQ";
        return "SAX";
    }

    private SearchParams ReadParams()
    {
        var parameters = new SearchParams { Keyword = keywordEntry.Text };

        AddIfSelected(parameters, "Faculty", facultyPicker);
        AddIfSelected(parameters, "Department", departmentPicker);
        AddIfSelected(parameters, "Course", coursePicker);

        if (floorPicker.SelectedItem is string floor)
            parameters.Floor = floor;

        return parameters;
    }

    private static void AddIfSelected(SearchParams parameters, string attribute, Picker picker)
    {
        if (picker.SelectedItem is string value)
            parameters.Attributes[attribute] = value;
    }

    private void ResetForm()
    {
        facultyPicker.SelectedIndex = -1;
        departmentPicker.SelectedIndex = -1;
        coursePicker.SelectedIndex = -1;
        floorPicker.SelectedIndex = -1;
        keywordEntry.Text = "";
        output.Text = "";
        statusLabel.Text = "";
    }
}
